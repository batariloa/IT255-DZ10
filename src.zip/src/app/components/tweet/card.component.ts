import { Component, OnInit, Input } from '@angular/core';
import { Card } from './model';
import { Router, ActivatedRoute, ParamMap, RouterModule } from '@angular/router';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';


import { ApiService } from 'src/app/services/api.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-tweet',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})

export class CardComponent implements OnInit {

  public cardData2:any;
  data:any;
  id:number;
  



  constructor(private api:ApiService, private http:HttpClient, private route:ActivatedRoute) {
   
  this.id=0;
   
  }

   ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.id = params['id'];
      
      
    });
   
    this.nadjiKartu();
 
    }

    nadjiKartu(){
  (this.api.getCards(this.id))!.subscribe((res:any)=>{
        this.cardData2 = res.data;
        console.log("yipe");
        console.log(this.cardData2);
      });
  }

  

}